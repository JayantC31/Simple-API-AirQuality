# Utility functions 


def sumvalues(values: list):
    """
    Function recieves list and returns sum of all values 
    Raises Exception if non-numerical values appear
    
    Parameters:
        CountingSum(float): decimal integer
    Returns:    
        CountingSum: Sum of all values in list if all values are numbers
    """  
     
    CountingSum = 0 # Sum starts at 0 
    for i in values:
        if isinstance(i, float) or isinstance(i, int):
            # Check if all values are numerical, this means all values must be an integer or float
            CountingSum += i 
            # Add the numerical value to the Sum, looped for every value in the given list
        else:
            return "Non-numerical value has been given in list"
            # Raise exception if non-numerical value has been found
    
    return CountingSum


# Test case: print(sumvalues([1,7,2,5,1, 2, 1,]))

def maxvalue(values: list):
    """
    This function recieves list and returns value and index of maximum value in list
    Also excludes non-numerical values
    Parameters:
        MaxIndex(int): Index of MaxNumber in list
        MaxNumber(float): Maximum number found in given list
        Current(float): Value of current number, used in a loop for all values in given list

    """    
    MaxIndex = 0
    MaxNumber = 0
    Current = 0
    for i in values: # Loop through all values in given list
        if isinstance(i, float) or isinstance(i, int):
            continue
        # Check if all values are numbers
        else:
            return "Non-numerical value has been given in list"
            # If a non-numerical value is found then the function is ended
    
    for i in range(len(values)):
        Current = values[i]
        # go through all possible values
        if Current > MaxNumber:
            # check if value is a numerical value and compare current value to the max value
            MaxNumber = values[i]
            MaxIndex = i
            # if new value is the current max, replace max value and index
        else:        
            i+=1
            # go through all possible values
    return MaxIndex
    

# Test case: print(maxvalue([1,888,1,3,6, "c",93]))

def minvalue(values: list):
    """
    This function recieves list and returns value and index of minimum value in list
    Also excludes non-numerical values
    
    Parameters:
        MinIndex(int): Index of minimum value 
        MinNumber(float): Minimum number found in given list
        Current(float): Current number used in loop to check MinNumber and possibly replace the parameter
    
    """    
    MinIndex = 0
    MinNumber = 99999999999999999999999999999999999999999999999999999
    # make current min number close to infinity so no value can be bigger
    Current = 0

    for i in values:
        if isinstance(i, float) or isinstance(i, int):
            continue
        # Check if all values are numbers
        else:
            return "Non-numerical value has been given in list"
            # End function if non-numerical value is found



    for i in range(len(values)):
        Current = values[i]
        # look at all values using Current
        if Current < MinNumber:
            # check if value is a numerical value and check if it is smaller then previous numbers
            MinNumber = values[i]
            MinIndex = i
            # replace minimum value and index if match is found
        else:        
            i+=1
            # go through all values in list
    return MinIndex

# Test case: print(minvalue([2,3.2,5,4,0.11,0.12,2,3,4,8]))

def meannvalue(values: list):
    """
    This function finds the mean of all numerical values in a given list
    Also ignores all non-numerical values
    Done by using the Equation of mean = a[0]+....a[n-1]/n
    
    Parameters: 
        Count(float): Find sum of values in given list assuming all values are numbers
        NumOfValues(int): Count number of values in given list
        Mean(float): Find Mean by dividing Count by NumOfValues
    """    
    
    Count = 0
    
    for i in values:
        if isinstance(i, float) or isinstance(i, int):
            continue
        # Check if all values are numbers
        else:
            return "Non-numerical value has been given in list"
            # End function if non-numerical value has been found

    NumOfValues = len(values)
    for i in range(len(values)):
        # go through each value in the new list
        Count += values[i]
        i+=1
        # look at each value and add it to total count
    
    if NumOfValues > 0:
        Mean = Count/NumOfValues
        return Mean
        # return the mean using the mean equation given there are values in the new list
    else:
        return 0
        # if there were no numerical values in the list, the function will print 0

# Test case: print(meannvalue([5,10,15,50, 100.12121]))

def countvalue(values: list, xw: str):
    """
    This function looks at a given value and checks a given list
    Comparing the value to all values inside the list, the function will count how many times it is repeated 
    It will return the number of occurences
    
    Parameters:
        x1(str): value given by user to find instances in given list 
        Count(int): Count number of times x1 has been found
        
    """    
    Count = 0
    # incase there are no occurences, the count is kept at 0
    for i in range(len(values)):
        if values[i] == xw:
            # looks at each value and compares with given x
            Count +=1
            # adds to total count
            
    i +=1
    # makes sure to go through each value in the list
    
    return Count


#print(countvalue([1,1,1,1,1,2,3,4,5,6,"a", "b"], 1))
