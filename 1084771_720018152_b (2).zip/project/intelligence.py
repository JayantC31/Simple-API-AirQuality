import numpy as np
from matplotlib import pyplot as mat_plot
from skimage import io
from skimage import color



def find_red_pixels(map_filename, upper_threshold=100, lower_threshold=50):
    """
    This function recieves map file from user and finds all red pixels

    Parameters:
        map_filename: File to be used
        upper/lower threshold: to find rgb and determine colour of each pixel
    Variables: 
        Map_file: file from skimage containing data of file
        image_data: rgb data for the image
        row: data for each row of pixels in image
    Returns:
        new image: image with only red pixels
        image data: 2d array of binary image
    """
    Map_file = io.imread(map_filename) # read using given file, using skimage
    Map_file = color.rgba2rgb(Map_file) # change file from RGBA to RGB
    Map_file = np.asarray(Map_file) # find numpy array of file
    image_data = [] # find data for each pixel as array  
    for row in Map_file:
        temp_row_array=[] # create a temp array for each row
        for r,g,b in row:
            r *= 255; g *= 255; b *= 255 # times each value by 255 as rgb is found from 0-255
            
            if r > upper_threshold and g < lower_threshold and b < lower_threshold: # if red is found and not green or blue
                temp_row_array.append(np.array([1,1,1]).astype(float)) # change pixel to all white(1,1,1)
            else:
                temp_row_array.append(np.array([0,0,0]).astype(float)) # else remove pixel by changing to all black(0,0,0)

        image_data.append(temp_row_array) # append data of row to new image

    image_data = np.array(image_data).astype(float) # create array with numpy with float values
    new_image = io.imsave("map-red-pixels.jpg",image_data) # save it to new file
    myimg = io.imread("map-red-pixels.jpg")  #read file and show file to user
    
    io.imshow(myimg) 
    io.show()
    return  image_data # return data of values of binary image
    

#print(find_red_pixels("./data/map.png"))


def find_cyan_pixels(map_filename, upper_threshold=100, lower_threshold=50):
    """
    This function recieves map file from user and finds all cyan pixels
    cyan = mix of green and blue
    Parameters:
        map_filename: File to be used
        upper/lower threshold: to find rgb and determine colour of each pixel
    Variables: 
        Map_file: file from skimage containing data of file
        image_data: rgb data for the image
        row: data for each row of pixels in image
    Returns:
        new image: image with only cyan pixels
        image data: 2d array of binary image
    """

    Map_file = io.imread(map_filename) # read using given file, using skimage
    Map_file = color.rgba2rgb(Map_file) # change file from RGBA to RGB
    Map_file = np.asarray(Map_file) # find numpy array of file
    image_data = [] # find data for each pixel as array  
    for row in Map_file:
        temp_row_array=[] # create a temp array for each row
        for r,g,b in row:
            r *= 255; g *= 255; b *= 255 # times each value by 255 as rgb is found from 0-255

            if r < upper_threshold and g > lower_threshold and b > lower_threshold:  # cyan is a mix of green and blue but not red
                temp_row_array.append(np.array([1,1,1]).astype(float)) # turn pixel to white(1,1,1)
            else:
                temp_row_array.append(np.array([0,0,0]).astype(float)) # else remove pixel by turning it to black(0,0,0)

        image_data.append(temp_row_array) # append data of row to new image
    
    image_data = np.array(image_data).astype(float) # create array with numpy with float values
    new_image = io.imsave("map-cyan-pixels.jpg",image_data) # save it to new file
    myimg = io.imread("map-cyan-pixels.jpg")  #read file and show file to user
    
    io.imshow(myimg) 
    io.show()


#print(find_cyan_pixels("./data/map.png"))



def detect_connected_components(map_filename):
    """Your documentation goes here"""
    # Your code goes here

def detect_connected_components_sorted(*args,**kwargs):
    """Your documentation goes here"""
    # Your code goes here

