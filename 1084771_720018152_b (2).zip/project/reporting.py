import numpy as np
import pandas as pd

# all the pollutants and Stations given, made into 2 arrays to make coding easier to read and write
Pollutants = ["no", "pm10", "pm25"]
Stations = ["Harlington", "Marylebone Road", "N Kensington"]



def daily_average(data, monitoring_station: str, pollutant: str):
    """
    Returns a list with the daily average(365 values) for any given pollutant and station
    This function uses my global Stations and Pollutants arrays to make it easier to code

    Parameters and variables:
        data: csv file turned into array
        monitoring_station: chosen station by user
        pollutant: chosen pollutant by user
        PollutantPicked: chosen pollutant index from data
        ArrayCalc: 365 arrays each containing values to be calculated on for daily values
        Hour1/Hour2/CurrentCount/CountPerDate: temp variables to iterate over array 

    Returns:
        DailyAverageList: List including all daliy averages(365 values returned in list)

    """
   
    # Check if both pollutant and Station are inputted correctly
    if pollutant in Pollutants:
        if monitoring_station in Stations:
            print("Data recieved")
        else:
            return "No station given"
    else:
        return "No pollutant given"

    # data is variable used to read the csv file for the station that has been inputted
    data = pd.read_csv(r'data\Pollution-London {monitoring_station}.csv'.format(monitoring_station=monitoring_station), header=None).values
    # PollutantPicked is index of pollutant the user picks, 2 is added as first 2 columns are not pollutants 
    PollutantPicked = Pollutants.index(pollutant) + 2
    
    # hour1/2 are used to iterate through each 24hours of the day
    hour1 = 1
    hour2 = 25
    
    # List is made to be returned at the end
    DailyAverageList = []
    # For loop to find daily average for each day
    for dates in range(365):
        ArrayCalc = (data[hour1:hour2, PollutantPicked])
        #print(ArrayCalc)
        # ArrayCalc variable used to make a new array for every value for each day
        # Two new variables to find total and divide by amount of values in array
        CurrentCount = 0
        CountPerDate = 0
        for i in (ArrayCalc):
            # iterate over each value
            if i != "No data":
                # go through each value that is a float
                CurrentCount += float(i) 
                CountPerDate += 1
            else:
                continue
            # ignore "No data" values in array
            
            DailyAverage = CurrentCount/CountPerDate
            # find daily average from simple divison
            DailyAverage = round(DailyAverage,4)
            # round to 4 dp
            
        # add each value to final list
        DailyAverageList.append(DailyAverage)
        # iterate over each day(24 hours)
        hour1 += 24
        hour2 += 24
        dates += 1        
        
    return(DailyAverageList)   


#print(daily_average("", "Marylebone Road", "pm25"))


def daily_median(data, monitoring_station: str, pollutant: str):
    """
    Returns a list with the daily median(365 values) for any given pollutant and station
    This function uses my global Stations and Pollutants arrays to make it easier to code

    Parameters and variables:
        data: csv file turned into array
        monitoring_station: chosen station by user
        pollutant: chosen pollutant by user
        PollutantPicked: chosen pollutant index from data
        ArrayCalc: 365 arrays each containing values to be calculated on for daily values
        SortArray: new list containing all float values from each ArrayCalc for each day
        Hour1/Hour2/MedianIndex/CountPerDate: temp variables to iterate over array 

    Returns:
        DailyMedianList: List including all daliy medians(365 values returned in list)
        
    """
    
    # Check if both pollutant and Station are inputted correctly
    if pollutant in Pollutants:
        if monitoring_station in Stations:
            print("Data recieved")
        else:
            return "No station given"
    else:
        return "No pollutant given"

    # data is variable used to read the csv file for the station that has been inputted
    data = pd.read_csv(r'data\Pollution-London {monitoring_station}.csv'.format(monitoring_station=monitoring_station), header=None).values
    # PollutantPicked is index of pollutant the user picks, 2 is added as first 2 columns are not pollutants 
    PollutantPicked = Pollutants.index(pollutant) + 2
    
    # hour1/2 are used to iterate through each 24hours of the day
    hour1 = 1
    hour2 = 25
    
    # List is made to be returned at the end
    DailyMedianList = []
    DailyMedian = 0
    # For loop to find daily average for each day
    for dates in range(365):
        ArrayCalc = (data[hour1:hour2, PollutantPicked])
        # ArrayCalc variable used to make a new array for every value for each day
        CountPerDate = 0
        # New array made to sort each list of values for each day
        SortArray = []
        for i in (ArrayCalc):
            # iterate over each value
            if i != "No data":
                SortArray.append(i)
                CountPerDate += 1
                # Add all float values to new list for each day
            else:
                continue
            # ignore "No data" values in array

        # Simple insertion sort to sort array to find median
        for i in range(1, len(SortArray)):
            test = SortArray[i]
            # test value looks at each value
            i2 = i-1
            # i2 value is value before test value
            while test < SortArray[i2] and i2 >= 0:
                # check if value should be ahead (greater) of current test value
                    SortArray[i2+1] = SortArray[i2]
                    i2 = i2 - 1
            #check next value           
            SortArray[i2+1] = test    


        #print(SortArray)
        # if count MOD 2 = 1 then length of list is uneven
        if CountPerDate % 2 == 1:
            MedianIndex = int(len(SortArray) / 2)
            # list is uneven, middle value is median
            DailyMedian = SortArray[MedianIndex]
            # add median to final list
            DailyMedianList.append(float(DailyMedian))
            

        # if not uneven then list is even
        else:
            # need to find 2 values as list is even
            # find index of middle value and middle value - 1 
            MedianIndex1 = int(len(SortArray) / 2) - 1
            MedianIndex2 = int(len(SortArray) / 2) 
            # for even list, add 2 values and /2 to find median
            if MedianIndex1 > 1: # make sure not to add arrays with less then 1 item inside
                DailyMedian = (float(SortArray[MedianIndex1]) + float(SortArray[MedianIndex2]))/2
                # round to 4 dp
                DailyMedian = round(float(DailyMedian),4)
                # add to final list
                DailyMedianList.append(DailyMedian)
            
        
        # iterate over each day(24 hours)
        hour1 += 24
        hour2 += 24
        dates += 1        
        
    return(DailyMedianList)


#print(daily_median("", "Marylebone Road", "pm25"))


def hourly_average(data, monitoring_station: str, pollutant: str):
    """
    Returns list of 24 values, including hourly averages for each chosen pollutant and station

    Parameters and variables:
        data: csv file turned into array
        monitoring_station: chosen station by user
        pollutant: chosen pollutant by user
        PollutantPicked: chosen pollutant index from data
        ArrayCalc: 365 arrays each containing values to be calculated on for daily values
        hour/Hour1/Hour2/MedianIndex/CountPerDate: temp variables to iterate over array 

    Returns:
        HourlyAverageList: List including all hourly averages(24 values returned in list)
        
    """
    
    
    # Check if both pollutant and Station are inputted correctly
    if pollutant in Pollutants:
        if monitoring_station in Stations:
            print("Data recieved")
        else:
            return "No station given"
    else:
        return "No pollutant given"

    # data is variable used to read the csv file for the station that has been inputted
    data = pd.read_csv(r'data\Pollution-London {monitoring_station}.csv'.format(monitoring_station=monitoring_station), header=None).values
    # PollutantPicked is index of pollutant the user picks, 2 is added as first 2 columns are not pollutants 
    PollutantPicked = Pollutants.index(pollutant) + 2
    
    # hour1/2 are used to iterate through each every hour in all 365 days
    # hour is used to check for each hour of the day
    HourlyAverageList = []
    for hour in range(1,25):
        hour1 = hour
        hour2 = hour + 1
        # For loop to find daily average for each day
        for dates in range(365):
            ArrayCalc = (data[hour1:hour2, PollutantPicked])
            # ArrayCalc finds each value for the hour chosen
            CurrentCount = 0
            CountPerHour = 0
            for i in ArrayCalc:
                if i != "No data":
                    CurrentCount += float(i)
                    CountPerHour += 1
                else:
                    continue
                    # check to make sure only numbers are chosen
                HourlyAverage = CurrentCount/CountPerHour
                # find average by simple division
              
                
            # iterate over each day(24 hours)
            hour1 += 24
            hour2 += 24
            dates += 1   
        # add average to final list
        HourlyAverageList.append(HourlyAverage)
        # check for the next hour
        hour += 1
    
    return(HourlyAverageList)


#print(hourly_average("", "Harlington", "pm25"))


def monthly_average(data, monitoring_station: str, pollutant: str):
    """
    Returns a list with the monthly average(12 values) for any given pollutant and station
    This function uses my global Stations and Pollutants arrays to make it easier to code

    Parameters and variables:
        data: csv file turned into array
        monitoring_station: chosen station by user
        pollutant: chosen pollutant by user
        month/CurrentPollutant: Specific column from data that is needed
        CurrentCount/CountPerMonth/MonthlyAverages: 3 variables used to calculate average
        i/j: simple variables used in for loops

    Returns:
        MonthlyAveragesList: List including all monthly averages(12 values returned in list)

    """


    # Check if both pollutant and Station are inputted correctly
    if pollutant in Pollutants:
        if monitoring_station in Stations:
            print("Data recieved")
        else:
            return "No station given"
    else:
        return "No pollutant given"

    # data is variable used to read the csv file for the station that has been inputted
    data = pd.read_csv(r'data\Pollution-London {monitoring_station}.csv'.format(monitoring_station=monitoring_station), skipinitialspace=True)
    
    # Final list to be outputted
    MonthlyAverageList = []

    # find index of each day and the current pollutant to be used
    month = data['date'].tolist()
    CurrentPollutant = data[pollutant].tolist()
    
    # list of all months in csv 
    Months = ["2021-01", "2021-02","2021-03","2021-04","2021-05","2021-06","2021-07","2021-08"
    ,"2021-09","2021-10", "2021-11", "2021-12"]

    # double for loop in order to find all data for each hour per each of 12 months
    for j in range(12):
        CurrentCount = 0
        CountPerMonth = 0
        for i in range(8760):
            # checks if the day is in the same month
            if Months[j] in month[i]:
                # only look sat data that is a number
                if CurrentPollutant[i] != "No data":
                    CurrentCount += float(CurrentPollutant[i])
                    # add each value to count
                    CountPerMonth += 1
                else:
                    continue
                # simple division to find average
                MonthlyAverage = CurrentCount/CountPerMonth
                MonthlyAverage = round(MonthlyAverage,4)
                # round to 4 dp
                    
                    
            i += 1
        j += 1
        # add each value to final list
        MonthlyAverageList.append(MonthlyAverage)
        
            
    return(MonthlyAverageList)


#print(monthly_average("", "Marylebone Road", "pm25"))



def peak_hour_date(data, date: str, monitoring_station: str,pollutant: str):
    """
    Returns the highest pollution level and the hour it occurs for any given day
    This function uses my global Stations and Pollutants arrays to make it easier to code

    Parameters and variables:
        data: csv file turned into array
        date: specific date needed to find, given by user
        monitoring_station: chosen station by user
        pollutant/CurrentPollutant: chosen pollutant by user
        day/time: specific columns needed to search through csv
        PeakFound/TimeFound: the max and time of max to be found
        test: temp variable used to find max value in list of 24 values
        i/j/k: simple temp variables used in for loops

    Returns:
        TimeFound, PeakFound: time of occurance and peak of given day

    """
    
    # Check if both pollutant and Station are inputted correctly
    if pollutant in Pollutants:
        if monitoring_station in Stations:
            print("Data recieved")
        else:
            return "No station given"
    else:
        return "No pollutant given"

    # data is variable used to read the csv file for the station that has been inputted
    data = pd.read_csv(r'data\Pollution-London {monitoring_station}.csv'.format(monitoring_station=monitoring_station), skipinitialspace=True)
    
    # find index of each day and the current pollutant to be used
    day = data['date'].tolist()
    j = 0 # temp used in for loop to find day the user has submitted
    for i in range(8760):
        if day[i] == date:
            break

        j += 1

    # for loop to find the specific day asked for and all values needed 
    if date == day[j]:
        CurrentPollutant = data[pollutant].tolist()
        # find all values needed to find peak value
        PeakHourList = (CurrentPollutant[j:j+24])
        # new list for new data set to be searched through
        test = 0
        for i in (PeakHourList):
            if i != "No data":
                if float(i) > float(test):
                    test = i
        # simply go through each value to find max
        PeakFound = test
    # find hour of max value
    k=0
    for i in PeakHourList:
        if PeakFound == i:
            # search the list for the max value
            time = data['time'].tolist()
            TimeFound = time[k]
            # if hour is found then return hour and peak
            return(TimeFound, PeakFound)
        else:
            # look through next value in list
            k += 1
            continue

       
#print(peak_hour_date("", "2021-02-01", "N Kensington", "no"))     



def count_missing_data(data,  monitoring_station: str,pollutant: str):
    """
    Returns Number of Missing data entries for given station and pollutant
    This function uses my global Stations and Pollutants arrays to make it easier to code

    Parameters and variables:
        data: csv file turned into array
        monitoring_station: chosen station by user
        pollutant/CurrentPollutant: chosen pollutant by user
        PollutantList: specific column needed to search through csv
        NumofMissingData: variable used to count
        i: simple temp variable used in for loops

    Returns:
        NumofMissingData: Number of times "No data" has appeared in data
    """
    
    if pollutant in Pollutants:
        if monitoring_station in Stations:
            print("Data recieved")
        else:
            return "No station given"
    else:
        return "No pollutant given"

    # data is variable used to read the csv file for the station that has been inputted
    data = pd.read_csv(r'data\Pollution-London {monitoring_station}.csv'.format(monitoring_station=monitoring_station), skipinitialspace=True)
    
    # find index of each day and the current pollutant to be used
    PollutantList = data[pollutant].tolist()
    # variable used to find num of entries in data set
    NumOfMissingData = 0
    for i in range(8760):
        # range of every value
        if PollutantList[i] == "No data":
            NumOfMissingData += 1
        else:
            continue

    return(NumOfMissingData)


#print(count_missing_data("", "Harlington", "pm25"))


def fill_missing_data(data, new_value,  monitoring_station: str,pollutant: str):
    """
    Returns copy of data with missing values replaced with new value given by user
    This function uses my global Stations and Pollutants arrays to make it easier to code
    Parameters and variables:
        data: csv file turned into array
        newfile: new file with only specific column
        PollutantList: list of the pollutant and the values inside to be used
    Returns:
        ReplacedFile: New list with all "no data" values replaced
    
    
    """
    
    if pollutant in Pollutants:
        if monitoring_station in Stations:
            print("Data recieved")
        else:
            return "No station given"
    else:
        return "No pollutant given"

    # data is variable used to read the csv file for the station that has been inputted
    data = pd.read_csv(r'data\Pollution-London {monitoring_station}.csv'.format(monitoring_station=monitoring_station), skipinitialspace=True)
    newfile = data.filter([pollutant], axis=1) # make new file for only specific coloumn
    
    # find index of each day and the current pollutant to be used
    PollutantList = data[pollutant].tolist()
    for i in range(8760):
        # range of every value
        if PollutantList[i] == "No data": # find all values with no data
            ReplacedFile=newfile.replace(PollutantList[i],new_value) # replace all no data with new value

        else:
            continue # if not no data then skip
    
    print(ReplacedFile)

    


#fill_missing_data("", 1211111111111111111111111111111111111111111111111111111212, "Harlington", "pm10")